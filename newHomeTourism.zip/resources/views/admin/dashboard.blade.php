@extends('...layouts.admin')

@section('content')
    <h1>Hello admin dfljaaaaaaaaaaaaaaaaaaaaaafjwojeiiiiiiiiiiiiiiiiiiiiiiifja</h1>
@endsection