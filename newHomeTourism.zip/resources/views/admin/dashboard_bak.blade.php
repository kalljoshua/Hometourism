@extends('...layouts.admin')

@section('sidebar')
    @parent
    @include('.admin.sidebar')
@endsection

@section('content')
    <h1>Hello admin dfljaaaaaaaaaaaaaaaaaaaaaafjwojeiiiiiiiiiiiiiiiiiiiiiiifja</h1>
@endsection