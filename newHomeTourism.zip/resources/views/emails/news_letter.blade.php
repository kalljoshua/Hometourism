<h2>Hello</h2>
<h3 style="text-transform:capitalize">{{ $newsLetter->title }}</h3>
<p>{!! $newsLetter->body !!}</p>
<p>Thank you.</p>