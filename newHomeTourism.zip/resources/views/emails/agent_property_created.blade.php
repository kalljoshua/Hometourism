<h2>Hello {{$property->agent->last_name}}</h2>
<h3>Your property has been added successfully</h3>
<p>Property title: <strong>{{$property->title}}</strong></p>
<p>Contact e-NYUMBANI Support on <strong>0785570221</strong> to make payments and have it activated</p>
<p>Thank you.</p>