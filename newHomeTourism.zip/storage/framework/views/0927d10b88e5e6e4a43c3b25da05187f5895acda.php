<header id="masthead" class="site-header" role="banner">
    <div class="site-header-head clearfix">
        <div class="container header-user h-card">
            <?php if(Auth::guard('user')->user() ): ?>
            <div class="header-tour-package pull-right">
                <span><?php echo e(Auth::guard('user')->user()->name); ?></span>
                <i class="fa fa-user"></i>
                <section class="header-tour-listing clearfix">
                    <h1 class="hide">Title</h1>
                    <article class="header-tour clearfix">
                        <div class="contents">
                            <span class="user-footer">
                                <div class="pull-left">
                                    <a href="<?php echo e(route('admin.user.edit.form',['id'=>Auth::guard('user')->user()->id])); ?>"
                                       class="btn btn-info btn-flat">Profile</a>
                                </div>
                            </span>
                            <span class="user-footer">
                                <div class="pull-right">
                                    <a href="#" onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();"
                                       class="btn btn-danger btn-flat">Sign out</a>
                                </div>
                                <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="POST"
                                      style="display: none;">
                            <?php echo e(csrf_field()); ?></form>
                            </span>
                        </div>
                    </article>

                </section>
            </div>
            <?php else: ?>
                <div class="header-tour-package pull-right">
                    <span><a href="<?php echo e(route('user.login')); ?>"><i class="lnr lnr-enter"></i> Login/Signup</a></span>&nbsp;
                    <i class="fa fa-user"></i>
                </div>

            <?php endif; ?>
            <div class="header-user-tel pull-right">
                <i class="fa fa-mobile-phone fa-lg"></i>
                <span class="tel">+012 345 6789</span>
            </div>

            <div class="header-user-email pull-right">
                <i class="fa fa-envelope-o"></i>
                <a class="u-url" href="mailto:info@example.com" >INFO@EXAMPLE.COM</a>
            </div>
        </div>
    </div>
    <div class="site-branding">
        <div class="container">
            <h1 class="site-title pull-left" style="color: red; font-style: italic;">
                <a href="/" rel="home">
                    
                    HomeTourism
                </a>
            </h1>
            <nav class="main-nav pull-right" role="navigation">
                <div class="menu-primary-menu-container">
                    <ul id="menu-primary-menu" class="main-menu">

                        <li><a class="btn btn-danger btn-post" href="<?php echo e(route('company.create')); ?>">
                                <span class="fa fa-plus-circle"></span> <b>Add a Home</b></a></li>

                        <li>
                            <a href="blog.html">Blog</a>
                            <ul class="sub-menu">
                                <li><a href="single.html">Single</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </nav>
        </div><!-- .container -->
    </div><!-- .site-branding -->
</header><!-- .site-header -->